import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BaseDeDatosProducto baseDatos = new BaseDeDatosProducto();
        

        // agrega pproducto a la base de datos 
        baseDatos.agregarProducto(1, "Manzanas", 5000.0, 25);
        baseDatos.agregarProducto(2, "Limones", 2300.0, 15);
        baseDatos.agregarProducto(3, "Peras", 2700.0, 33);
        baseDatos.agregarProducto(4, "Arandanos", 9300.0, 5);
        baseDatos.agregarProducto(5, "Tomates", 2100.0, 42);
        baseDatos.agregarProducto(6, "Fresas", 4100.0, 3);
        baseDatos.agregarProducto(7, "Helado", 4500.0, 41);
        baseDatos.agregarProducto(8, "Galletas", 500.0, 8);
        baseDatos.agregarProducto(9, "Chocolotes", 3500.0, 80);
        baseDatos.agregarProducto(10, "Jamon", 15000.0, 10);
        

        // Leer el número de casos a ejecutar
        int numCasos = Integer.parseInt(scanner.nextLine());

        // Ejecutar las operaciones<
        for (int i = 0; i < numCasos; i++) {
            String operacion = scanner.nextLine();
            String[] datos = scanner.nextLine().split(" ");
            int codigo = Integer.parseInt(datos[0]);
            String nombre = datos[1];
            double precio = Double.parseDouble(datos[2]);
            int inventario = Integer.parseInt(datos[3]);

              // Realizar la operación solicitada en la base de datos
            baseDatos.realizarOperacion(operacion, codigo, nombre, precio, inventario);
        }

        // Calcular y mostrar las estadísticas de la base de datos
        baseDatos.calcularEstadisticas();
    }
}


