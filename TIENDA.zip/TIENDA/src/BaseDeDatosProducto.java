import java.util.HashMap;
import java.util.Map;

public class BaseDeDatosProducto {
    Map<Integer, Producto> listaProductos = new HashMap<>();

    public void agregarProducto(int codigo, String nombre, double precio, int inventario) {
        if (!listaProductos.containsKey(codigo)) {
            listaProductos.put(codigo, new Producto(codigo, nombre, precio, inventario));
        } else {
            System.out.println("ERROR");
        }
    }

    public void actualizarProducto(int codigo, String nombre, double precio, int inventario) {
        if (listaProductos.containsKey(codigo)) {
            listaProductos.put(codigo, new Producto(codigo, nombre, precio, inventario));
        } else {
            System.out.println("ERROR");
        }
    }

    public void borrarProducto(int codigo) {
        if (listaProductos.containsKey(codigo)) {
            listaProductos.remove(codigo);
        } else {
            System.out.println("ERROR");
        }
    }

    public void realizarOperacion(String operacion, int codigo, String nombre, double precio, int inventario) {
        switch (operacion) {
            case "agregar":
                agregarProducto(codigo, nombre, precio, inventario);
                break;
            case "actualizar":
                actualizarProducto(codigo, nombre, precio, inventario);
                break;
            case "borrar":
                borrarProducto(codigo);
                break;
            default:
                break;
        }
    }

    public void calcularEstadisticas() {
        double sumaPrecios = 0.0;
        double precioMayor = Double.MIN_VALUE;
        double precioMenor = Double.MAX_VALUE;
        String productoPrecioMayor = "";
        String productoPrecioMenor = "";

        for (Producto producto : listaProductos.values()) {
            sumaPrecios += producto.precio;
            if (producto.precio > precioMayor) {
                precioMayor = producto.precio;
                productoPrecioMayor = producto.nombre;
            }
            if (producto.precio < precioMenor) {
                precioMenor = producto.precio;
                productoPrecioMenor = producto.nombre;
            }
        }

        double promedioPrecios = sumaPrecios / listaProductos.size();
        double valorInventarioTotal = 0.0;
        for (Producto producto : listaProductos.values()) {
            valorInventarioTotal += producto.precio * producto.inventario;
        }

        System.out.println(productoPrecioMayor);
        System.out.println(productoPrecioMenor);
        System.out.println(promedioPrecios);
        System.out.println(valorInventarioTotal);
    }
}
    

